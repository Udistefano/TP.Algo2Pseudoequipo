package Tests;

public class TestDeCarta {

    public void TestDeCarta() {
//        Carta cartaBloquearFicha = new CartaBloquearFicha(...);
//        Carta cartaAnularTurno = new CartaAnularTurno(...);
//
//        cartaBloquearFicha.realizarMovimientoEspecial();
//        cartaAnularTurno.realizarMovimientoEspecial();
//         cartaBloquearFicha.realizarMovimientoEspecial()

//        cartaPerderTurno.realizarMovimientoEspecial(Jugador jugador1)
//        cartaAnularCasillero.realizarMovimientoEspecial(Casillero casillero) // o coordenadas
//        cartaCambiarColorDeFicha.realizarMovimientoEspecial(ficha, jugador1, jugador2)
    }
}
