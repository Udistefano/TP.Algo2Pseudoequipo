package Tests;


import Estructuras.Lista;
import Main.Jugador;



public class MainCartasBorrarMazoJugador {
//	Jugador Adolfo = new Jugador('c', "Adolfo");
//	Jugador Roberto = new Jugador('x', "Roberto");
	
	Lista<Jugador> jugadores = new Lista<Jugador>();
	//jugadores.agregar(Adolfo);
	
	//Partida tateti = new Partida();
}
