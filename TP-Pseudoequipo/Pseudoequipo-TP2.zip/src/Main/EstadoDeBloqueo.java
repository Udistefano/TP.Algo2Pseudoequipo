package Main;

public enum EstadoDeBloqueo {
    BLOQUEADO,
    DESBLOQUEADO
}
